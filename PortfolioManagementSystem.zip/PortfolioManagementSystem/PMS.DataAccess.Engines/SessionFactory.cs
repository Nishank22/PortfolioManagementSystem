﻿using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using NHibernate;
using PMS.DataAccess.Models.Entities;

namespace PMS.DataAccess.Engines
{
    public class SessionFactory
    {
        public static ISessionFactory CreateSessionFactory()
        {

            string connectionString = "Data Source=.;Initial Catalog=PMS;User ID=sa;Password=Ncjkp$4552g";

            return Fluently.Configure()
                .Database(MsSqlConfiguration.MsSql2012.ConnectionString(connectionString).ShowSql()
                .DefaultSchema("dbo"))
                .Mappings(m => m.FluentMappings.AddFromAssemblyOf<User>())
                .BuildSessionFactory();

        }
    }
}
