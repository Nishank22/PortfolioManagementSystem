﻿using PMS.DataAccess.Engines.ServiceContracts;
using PMS.DataAccess.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.DataAccess.Engines
{
    public class UserPortfolioDataEngine : IUserPortfolioDataEngine
    {
        public bool AddUserSymbols(UserSymbols symbols)
        {
            var stocks = this.GetUserSymbols(symbols.UserId);
            if (stocks.Any(x => string.Equals(x.SymbolKey.Trim(), symbols.SymbolKey.Trim()))) {
                throw new Exception("Symbol already exists");
            }
            try
            {
                var sessionFactory = SessionFactory.CreateSessionFactory();
                using (var session = sessionFactory.OpenSession())
                {
                    using (var transaction = session.BeginTransaction())
                    {
                        session.Save(symbols);
                        transaction.Commit();
                    }
                    session.Flush();
                    session.Clear();
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IEnumerable<UserSymbols> GetUserSymbols(int userId)
        {
            try
            {
                var sessionFactory = SessionFactory.CreateSessionFactory();

                using (var session = sessionFactory.OpenSession())
                {
                    return session.QueryOver<UserSymbols>()
                            .Where(a => a.UserId == userId)
                            .List<UserSymbols>();
                }
            }
            catch
            {
                return null;
            }
        }

        public bool Delete(int id)
        {
            try
            {
                var sessionFactory = SessionFactory.CreateSessionFactory();
                using (var session = sessionFactory.OpenSession())
                {
                    using (var transaction = session.BeginTransaction())
                    {
                        UserSymbols user = new UserSymbols();
                        user.UserSymbolsId = id;
                        session.Delete(user);
                    }
                    session.Flush();
                    session.Clear();
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
