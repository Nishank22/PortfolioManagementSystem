﻿using PMS.DataAccess.Engines.ServiceContracts;
using PMS.DataAccess.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.DataAccess.Engines
{
    public class UsersDataEngine : IUsersDataEngine
    {
        public User CheckLogin(string userName, string password)
        {
            try
            {
                var sessionFactory = SessionFactory.CreateSessionFactory();

                using (var session = sessionFactory.OpenSession())
                {
                    var list= session.QueryOver<User>()
                            //.Where(a => String.Equals(userName, a.UserName) &&
                            //String.Equals(password, a.Password))
                            .List<User>();
                    return list.First(x => string.Equals(x.UserName, userName) && string.Equals(x.Password, password));
                }
            }
            catch
            {
                return null;
            }
        }

        public bool CreateUser(User user)
        {
            try
            {
                var sessionFactory = SessionFactory.CreateSessionFactory();

                using (var session = sessionFactory.OpenSession())
                {
                    using (var transaction = session.BeginTransaction()) {
                        session.Save(user);
                        transaction.Commit();
                        return true;
                    }
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

    }
}
