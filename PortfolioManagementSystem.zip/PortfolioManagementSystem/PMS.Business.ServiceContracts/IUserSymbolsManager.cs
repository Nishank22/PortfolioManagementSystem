﻿using PMS.Business.Implementations.Models;
using System.Collections.Generic;

namespace PMS.Business.ServiceContracts
{
    public interface IUserSymbolsManager
    {
        IEnumerable<UserSymbols> GetUserSymbols(int userId);
        bool AddUserSymbols(UserSymbols symbols);
        bool Delete(int id);
    }
}
