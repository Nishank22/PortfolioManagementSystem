﻿using PMS.Business.Implementations.Models;
namespace PMS.Business.ServiceContracts
{
    public interface IUserManager
    {
        bool CreateUser(User user);
        User CheckLogin(string userName, string password);
    }
}
