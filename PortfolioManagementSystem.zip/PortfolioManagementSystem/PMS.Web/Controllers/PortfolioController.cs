﻿using PMS.Business.Implementations;
using PMS.Business.ServiceContracts;
using PMS.Web.Models;
using System.Collections.Generic;
using System.Web.Http;

namespace PMS.Web.Controllers
{
    public class PortfolioController : ApiController
    {
        IUserSymbolsManager service = new UserSymbolsManager();
        // GET: api/Portfolio
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Portfolio/5
        public IHttpActionResult Get(int id)
        {
            return Ok(service.GetUserSymbols(id));
        }

        // POST: api/Portfolio
        public IHttpActionResult Post(UserSymbols userSymbol)
        {
            PMS.Business.Implementations.Models.UserSymbols req = new Business.Implementations.Models.UserSymbols()
            {
                InitialPricePerStock = userSymbol.InitialPricePerStock,
                NumberOfStocks = userSymbol.NumberOfStocks,
                SymbolKey = userSymbol.SymbolKey,
                SymbolName = userSymbol.SymbolName,
                UserId = userSymbol.UserId
            };
            return Ok(service.AddUserSymbols(req));
        }

        // PUT: api/Portfolio/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Portfolio/5
        public void Delete(int id)
        {
        }
    }
}
