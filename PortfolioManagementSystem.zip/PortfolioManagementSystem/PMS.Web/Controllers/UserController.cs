﻿using PMS.Business.Implementations;
using PMS.Business.Implementations.Models;
using PMS.Business.ServiceContracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PMS.Web.Controllers
{
    public class UserController : ApiController
    {
        // GET: api/User/5
        public IHttpActionResult Get(string u,string p)
        {
            IUserManager service = new UserManager();
            var res = service.CheckLogin(u, p);
            return Ok(res);
        }

        // POST: api/User
        public IHttpActionResult Post(User value)
        {
            IUserManager service = new UserManager();
            var res = service.CreateUser(value);
            return Ok(res);
        }
    }
}
