﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.Business.Implementations.Models;
using PMS.Business.ServiceContracts;
using PMS.DataAccess.Engines;
using PMS.DataAccess.Engines.ServiceContracts;

namespace PMS.Business.Implementations
{
    public class UserManager : IUserManager
    {
        IUsersDataEngine service = new UsersDataEngine();
        public User CheckLogin(string userName, string password)
        {
            var res = service.CheckLogin(userName, password);
            if (res != null)
            {
                return new User()
                {
                    Id = res.Id,
                    Name = res.Name,
                    UserName = res.UserName,
                    Password = res.Password
                };
            }
            return null;
        }

        public bool CreateUser(User user)
        {
            var request = new PMS.DataAccess.Models.Entities.User()
            {
                Id = user.Id,
                Name = user.Name,
                UserName = user.UserName,
                Password = user.Password
            };

            return service.CreateUser(request);
        }
    }
}
