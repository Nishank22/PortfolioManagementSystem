﻿using PMS.Business.Implementations.Models;
using PMS.Business.ServiceContracts;
using PMS.DataAccess.Engines;
using PMS.DataAccess.Engines.ServiceContracts;
using System;
using System.Collections.Generic;

namespace PMS.Business.Implementations
{
    public class UserSymbolsManager : IUserSymbolsManager
    {
        IUserPortfolioDataEngine service = new UserPortfolioDataEngine();

        public bool AddUserSymbols(UserSymbols symbols)
        {
            var request = new DataAccess.Models.Entities.UserSymbols()
            {
                UserSymbolsId = 0,
                InitialPricePerStock = symbols.InitialPricePerStock,
                SymbolKey = symbols.SymbolKey,
                SymbolName = symbols.SymbolName,
                NumberOfStocks = symbols.NumberOfStocks,
                UserId = symbols.UserId
            };

            return service.AddUserSymbols(request);
        }

        public IEnumerable<UserSymbols> GetUserSymbols(int userId)
        {
            var list = service.GetUserSymbols(userId);
            var res = new List<UserSymbols>();
            foreach (var item in list)
            {
                UserSymbols us = new UserSymbols()
                {
                    Id = item.UserSymbolsId,
                    InitialPricePerStock = item.InitialPricePerStock,
                    NumberOfStocks = item.NumberOfStocks,
                    SymbolKey = item.SymbolKey,
                    SymbolName = item.SymbolName,
                    UserId = item.UserId
                };
                res.Add(us);
            }
            return res;
        }

        public bool Delete(int id)
        {
            var res = service.Delete(id);
            return res;
        }
    }
}
