﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Business.Implementations.Models
{
    public class UserSymbols
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string SymbolName { get; set; }
        public long NumberOfStocks { get; set; }
        public decimal InitialPricePerStock { get; set; }
        public string SymbolKey { get; set; }
    }
}
