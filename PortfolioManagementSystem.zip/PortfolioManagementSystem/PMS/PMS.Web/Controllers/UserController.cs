﻿using PMS.Business.Implementations;
using PMS.Business.Implementations.Models;
using PMS.Business.ServiceContracts;
using System.Web.Http;

namespace PMS.Web.Controllers
{
    public class UserController : ApiController
    {
        public IHttpActionResult Get(string u,string p)
        {
            IUserManager service = new UserManager();
            var res = service.CheckLogin(u, p);
            return Ok(res);
        }

        public IHttpActionResult Post(User value)
        {
            IUserManager service = new UserManager();
            var res = service.CreateUser(value);
            return Ok(res);
        }
    }
}
