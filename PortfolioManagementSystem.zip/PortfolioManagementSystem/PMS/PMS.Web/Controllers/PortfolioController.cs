﻿using PMS.Business.Implementations;
using PMS.Business.ServiceContracts;
using PMS.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PMS.Web.Controllers
{
    public class PortfolioController : ApiController
    {
        IUserSymbolsManager service = new UserSymbolsManager();
        
        // GET: api/Portfolio/5
        public IHttpActionResult Get(int id)
        {
            return Ok(service.GetUserSymbols(id));
        }

        // POST: api/Portfolio
        public IHttpActionResult Post(UserSymbols userSymbol)
        {
            PMS.Business.Implementations.Models.UserSymbols req = new Business.Implementations.Models.UserSymbols()
            {
                InitialPricePerStock = userSymbol.InitialPricePerStock,
                NumberOfStocks = userSymbol.NumberOfStocks,
                SymbolKey = userSymbol.SymbolKey,
                SymbolName = userSymbol.SymbolName,
                UserId = userSymbol.UserId
            };
            return Ok(service.AddUserSymbols(req));
        }

        // DELETE: api/Portfolio/5
        [HttpDelete]
        public IHttpActionResult Delete(int id)
        {
            return Ok(this.service.Delete(id));
        }
    }
}
