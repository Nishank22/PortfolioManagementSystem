import { Quote } from "./Quote";
import { UserSymbol } from "./UserSymbol";

export class UserShare {
    public quote: Quote = new Quote();
    public userSymbol:UserSymbol = new UserSymbol();
}