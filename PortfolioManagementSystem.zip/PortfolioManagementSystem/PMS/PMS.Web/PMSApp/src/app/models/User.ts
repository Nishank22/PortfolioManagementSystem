export class User {
    Id: number = 0;
    Name: string = "";
    UserName: string = "";
    Password: string = "";
}