export class Quote {

    vwdKey: string = '';
    name: string = '';
    isin: string = '';
    price: number = 0;
    time: Date = new Date();
    open: number = 0;
    high: number = 0;
    low: number = 0;
    close: number = 0;
    volume: number = 0;
    previousClose: number = 0;
    previousCloseTime: Date = new Date();

}