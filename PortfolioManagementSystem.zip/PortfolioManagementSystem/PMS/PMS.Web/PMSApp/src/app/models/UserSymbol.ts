export class UserSymbol {

  public Id: number = 0;
  public UserId: number = 0;
  public SymbolName: string = "";
  public NumberOfStocks: number = 0;
  public InitialPricePerStock: number = 0;
  public SymbolKey: string = "";
}

