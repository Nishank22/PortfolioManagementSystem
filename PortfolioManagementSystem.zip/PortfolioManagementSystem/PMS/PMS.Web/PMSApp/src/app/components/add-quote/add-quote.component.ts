
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { PortfolioService } from 'src/app/services/portfolio.service';

@Component({ templateUrl: 'add-quote.component.html' })
export class AddQuoteComponent implements OnInit {
    form: FormGroup;
    loading = false;
    submitted = false;
    errorMessage = '';
    showError = false;
    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private portfolioService: PortfolioService
    ) {
        this.form = this.formBuilder.group({
            SymbolKey: ['', Validators.required],
            InitialPricePerStock: ['', Validators.required],
            NumberOfStocks: ['', [Validators.required]]
        });
    }

    ngOnInit() { }

    // convenience getter for easy access to form fields
    get f() { return this.form.controls; }

    onSubmit() {
        this.showError = true;
        this.submitted = true;

        // stop here if form is invalid
        if (this.form.invalid) {
            return;
        }

        this.loading = true;
        this.portfolioService.addUserStock(this.form.value)
            .subscribe(x => {
                this.loading = false;
                this.router.navigateByUrl('/watchList');
            }, (error) => {
                this.loading = false;
                this.errorMessage = "The current symbol already exists. Please try with another symbol!!!";
                this.showError = true;
            })
    }
}