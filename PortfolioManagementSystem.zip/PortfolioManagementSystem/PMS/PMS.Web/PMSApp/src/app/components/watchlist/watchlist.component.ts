import { Component, OnInit } from '@angular/core';
import { timer } from 'rxjs';
import { UserShare } from 'src/app/models/UserShare';
import { PortfolioService } from 'src/app/services/portfolio.service';
import { UserService } from 'src/app/services/user.service';
import { Quote } from '../../models/Quote';
import { QuotesService } from '../../services/quotes.service';
@Component({
  selector: 'app-watchlist',
  templateUrl: './watchlist.component.html',
  styleUrls: ['./watchlist.component.css']
})

export class WatchlistComponent implements OnInit {

  quoteList: Quote[] = [];
  userShares: UserShare[] = [];

  constructor(private quotesService: QuotesService, private userPortfolioService: PortfolioService, private userService: UserService) { }

  ngOnInit() {
    const source = timer(0, 5000);
    source.subscribe(_ =>
      this.getUserLatestPortfolioList()
    );
  }

  getUserLatestPortfolioList() {
    if (this.userService.getCurrentUser().Id > 0)
      this.userPortfolioService.getUserStocks().subscribe(userSymbols => {
        this.userShares = [];
        let stocksList: Array<string> = [];
        userSymbols.forEach(element => {
          stocksList.push("vwdKey=" + element.SymbolKey);
        });
        this.quotesService.getQuotes(stocksList.join('&')).subscribe((quoteList) => {

          quoteList.forEach(quote => {
            userSymbols.forEach(userSymbol => {
              if (quote.vwdKey == userSymbol.SymbolKey) {
                let userShare = new UserShare();
                userShare.userSymbol = userSymbol;
                userShare.quote = quote;
                this.userShares.push(userShare);
              }
            })
          })
        })
      })
  }

}
