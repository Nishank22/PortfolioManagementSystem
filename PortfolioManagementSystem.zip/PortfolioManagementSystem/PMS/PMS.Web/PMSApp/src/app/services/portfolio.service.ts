import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../models/User';
import { UserSymbol } from '../models/UserSymbol';
import { DataService } from './data.service';
import { UserService } from './user.service';

@Injectable({
  providedIn: 'root'
})
export class PortfolioService {

  constructor(private dataService: DataService, private userService: UserService) { }

  baseUrl: string = './api/Portfolio'

  getUserStocks(): Observable<UserSymbol[]> {
    return this.dataService.get(this.baseUrl + "?id=" + this.userService.getCurrentUser().Id);
  }

  addUserStock(stock: UserSymbol) {
    stock.UserId = this.userService.getCurrentUser().Id;
    return this.dataService.post(this.baseUrl, stock);
  }

  deleteUserStock(id: number) {
    console.log('In portfolio service :' +id)
    return this.dataService.delete(this.baseUrl + "?id=" + id);
  }
}
