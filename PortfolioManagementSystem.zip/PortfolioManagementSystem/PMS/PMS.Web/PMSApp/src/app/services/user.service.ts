import { Injectable } from '@angular/core';
import { User } from '../models/User';
import { DataService } from './data.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  url: string = "./api/User";
  currentLoggedInUser: User = new User();

  constructor(private dataService: DataService) { }

  checkLogin(userName: string, password: string) {
    let reqUrl = this.url + "?u=" + userName + "&p=" + password;
    return this.dataService.get(reqUrl);
  }

  registerUser(data: User) {
    return this.dataService.post(this.url, data);
  }

  setCurrentUser(user: any) {
    this.currentLoggedInUser = user;
  }

  getCurrentUser() {
    return this.currentLoggedInUser;
  }

  logOut() {
    this.currentLoggedInUser = new User();
  }
}
