﻿using FluentNHibernate.Mapping;
using PMS.DataAccess.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.DataAccess.Models.Mappings
{
    public class UserMap:ClassMap<User>
    {
        public UserMap() {
            Id(x => x.Id);

            Map(x => x.Name);
            Map(x => x.Password);
            Map(x => x.UserName);
        }
    }
}
