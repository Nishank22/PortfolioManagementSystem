﻿using FluentNHibernate.Mapping;
using PMS.DataAccess.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.DataAccess.Models.Mappings
{
    public class UserSymbolsMap:ClassMap<UserSymbols>
    {
        public UserSymbolsMap()
        {
            Id(x => x.UserSymbolsId);
            Map(x => x.UserId);
            Map(x => x.SymbolName);
            Map(x => x.SymbolKey);
            Map(x => x.NumberOfStocks);
            Map(x => x.InitialPricePerStock);

            //CompositeId()
            //.KeyProperty(x => x.UserId)
            //.KeyProperty(x => x.SymbolKey);
            //References<User>(x => x.UserId).Column("UserId").ForeignKey("Id");
        }

    }
}
