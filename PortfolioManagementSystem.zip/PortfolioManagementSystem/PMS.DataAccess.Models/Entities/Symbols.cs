﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.DataAccess.Models.Entities
{
    public class Symbols
    {
        public virtual int Id { get; set; }
        public virtual string SymbolKey { get; set; }
        public virtual int Name { get; set; }
    }
}
