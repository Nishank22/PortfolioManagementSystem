﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.DataAccess.Models.Entities
{
    public class UserSymbols
    {
        public virtual int UserSymbolsId { get; set; }
        public virtual int UserId { get; set; }
        public virtual string SymbolName { get; set; }
        public virtual long NumberOfStocks { get; set; }
        public virtual decimal InitialPricePerStock { get; set; }
        public virtual string SymbolKey { get; set; }
        
        public virtual User User { get; set; }
    }
}
